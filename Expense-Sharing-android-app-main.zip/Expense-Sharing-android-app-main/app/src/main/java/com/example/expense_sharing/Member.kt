package com.example.expense_sharing

data class Member(var memberName : String ?= null, var pendingDebts : String ?= null)
