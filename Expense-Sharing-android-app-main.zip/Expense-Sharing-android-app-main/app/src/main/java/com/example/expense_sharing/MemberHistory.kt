package com.example.expense_sharing

data class MemberHistory(var payeeMember : String ?= null, var share : String ?= null, var payingMember : String?= null, var eventName:String?=null, var date: String ?= null)
