package com.example.expense_sharing

data class User(var groupName : String ?= null, var groupPurpose : String ?= null)
