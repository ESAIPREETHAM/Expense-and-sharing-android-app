package com.example.expense_sharing

data class Useradd(val groupName: String ?= null, val groupPurpose: String ?= null)
