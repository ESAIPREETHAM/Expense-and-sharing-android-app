package com.example.expense_sharing

data class memberUser(var groupName : String ?= null)
