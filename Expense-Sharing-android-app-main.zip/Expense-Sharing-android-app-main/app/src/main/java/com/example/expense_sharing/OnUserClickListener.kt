package com.example.expense_sharing

interface OnUserClickListener {
    fun OnUserItemClicked(groupId : String)
}
