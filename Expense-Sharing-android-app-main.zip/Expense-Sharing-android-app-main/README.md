# Expense-Sharing-android-app
CS230 Project on expense sharing android app using Kotlin and Firebase with Gmail login with Acchda Hiren Rajkumar

